package com.example.Crud_App_Security.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.Crud_App_Security.models.Employee;
import com.example.Crud_App_Security.models.Role;
import com.example.Crud_App_Security.models.RolesEnum;
import com.example.Crud_App_Security.repo.EmployeeRepository;
import com.example.Crud_App_Security.repo.RoleRepo;


@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository emprepo;
	
	@Autowired
	RoleRepo roleRepo;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	public ArrayList<Employee> getAllEmployee() {
		
		ArrayList<Employee> emps = new ArrayList<Employee>();
		emprepo.findAll().forEach(Employee -> emps.add(Employee));
		return emps;
	}
	
	public Employee getEmployeeById(int id) {
		return emprepo.findById(id).get();
	}
	
	public String deleteEmployeeById(int id) {
		 emprepo.deleteById(id);
		 return "Deleted Successfully";
	}
	
	public void addEmployee(Employee e) {
		String pass =passwordEncoder.encode(e.getPassword());
		e.setPassword(pass);
		Set<Role> hs= new HashSet();
		  Role role =roleRepo.findByName("ROLE_USER").get();
		  hs.add(role);
		  e.setRoles(hs);
		  emprepo.save(e);
	}
	
	
	public void updateEmployee(Employee e ,int id) {
		ArrayList<Employee> emps = this.getAllEmployee();
		
		for(Employee e1:emps) {
			emprepo.delete(e1);
			emprepo.save(e);
			
		}

	}
	
}
