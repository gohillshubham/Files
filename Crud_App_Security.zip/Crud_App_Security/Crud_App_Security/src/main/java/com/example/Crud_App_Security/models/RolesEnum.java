package com.example.Crud_App_Security.models;

public enum RolesEnum {
	
	USER,ADMIN
}
