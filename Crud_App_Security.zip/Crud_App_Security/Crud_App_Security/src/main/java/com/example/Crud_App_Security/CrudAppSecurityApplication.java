package com.example.Crud_App_Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudAppSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudAppSecurityApplication.class, args);
	}

}
