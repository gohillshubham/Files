package com.example.Crud_App_Security.controllers;

import org.springframework.web.bind.annotation.RestController;

import com.example.Crud_App_Security.models.Employee;
import com.example.Crud_App_Security.service.EmployeeService;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
public class EmployeeControllers {
	
	@Autowired
	EmployeeService empservice;

	
	@GetMapping("/getemp")
	public ArrayList<Employee> getAllEmployee() {
		return empservice.getAllEmployee();
	}
	
	@GetMapping("/getemp/{id}")
	public Employee getEmployeeById(@PathVariable int id) {
		return empservice.getEmployeeById(id);
	}
	
	@DeleteMapping("/delemp/{id}")
	public void deleteEmployeeById(@PathVariable int id) {
		empservice.deleteEmployeeById(id);
	}
	
	
	@PostMapping("/addemp")
	public String addEmployee(@RequestBody Employee e) {
		empservice.addEmployee(e);
		return "User saved Successfully";
	}
	
	@PutMapping("/editemp/{id}")
	public void updateEmployee(@RequestBody Employee e,@PathVariable int id) {
		empservice.updateEmployee(e,id);
	}
}
