package com.example.Crud_App_Security.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Crud_App_Security.models.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	
	Employee findByName(String name);
	Employee findByEmail(String email);
}

