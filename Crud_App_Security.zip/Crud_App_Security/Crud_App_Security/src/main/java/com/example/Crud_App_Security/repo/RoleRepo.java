package com.example.Crud_App_Security.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.Crud_App_Security.models.Role;


public interface RoleRepo extends JpaRepository<Role, Integer>{
	
	@Query(value="SELECT * FROM `role` WHERE role= ?1",nativeQuery=true)
	Optional<Role> findByName(String name);
}
