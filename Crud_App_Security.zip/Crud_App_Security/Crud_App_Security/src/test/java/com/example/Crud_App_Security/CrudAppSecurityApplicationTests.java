package com.example.Crud_App_Security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudAppSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
